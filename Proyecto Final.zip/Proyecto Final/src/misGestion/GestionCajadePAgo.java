
package misGestion;
import archivo.cola.ArrayCola;
import archivos.pila.ArrayPila;
import misClases.Cliente;
import misClases.CajaDePago;

public class GestionCajadePAgo {
       private ArrayCola<Cliente> listaC;


    public GestionCajadePAgo() {
        listaC=new ArrayCola<Cliente>();
    }

   
    //reglas de negocio
    public void encolarCliente (Cliente refC){
       listaC.encolar(refC);
    }
    public String toString(){
        String cad="";
        ArrayCola<Cliente> cAux=new ArrayCola<Cliente>();
        while(listaC.colaVacia()==false){
            Cliente c=listaC.desencolar();
            cad=cad+c.toString()+"\n";
            cAux.encolar(c);
        }        
        while(cAux.colaVacia()==false){
            listaC.encolar(cAux.desencolar());
        }        
        return cad;
    }
    public void calcularMontoRecaudado(){
        
        while(listaC.colaVacia()==false){            
            Cliente c=listaC.desencolar();
            ArrayPila<CajaDePago> comp=c.getMontoPago();
            while(comp.pilaVacia()==false){
               CajaDePago p=comp.desapilar();
                                               
            }           
        }
    }
    
    
   
}
