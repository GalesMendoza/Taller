
package misClases;


public class Cliente {
    
     protected String dni;
     protected float montoPago;

    public Cliente(String dni, float montoPago) {
        this.dni = dni;
        this.montoPago=0.0f;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public float getMontoPago() {
        return montoPago;
    }

    public void setMontoPago(float montoPago) {
        this.montoPago = montoPago;
    }

    
}
