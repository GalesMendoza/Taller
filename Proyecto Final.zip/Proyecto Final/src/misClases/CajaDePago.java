
package misClases;

import archivo.cola.ArrayCola;
import javax.swing.JOptionPane;

public class CajaDePago {
//declaracion de variables
    private ArrayCola<Cliente> listaC;
    private float montoRCaja;
//contructor
    public CajaDePago() {
        listaC=new ArrayCola<Cliente>();
        montoRCaja=0.0f;
    }
//getters
    public ArrayCola<Cliente> getListaC() {
        return listaC;
    }
    public float getMontoRCaja() {
        return montoRCaja;
    }

//metodo asignar clientes a la cola
    public void agregarClienteEnCola(Cliente refC){
        boolean estado = false;
        ArrayCola<Cliente> colaAux = new ArrayCola<Cliente>();
        
        while(listaC.colaVacia()!=true && estado == false){
            Cliente c = listaC.desencolar();
            if (c.getDni()==refC.getDni()) {
                estado = true;
            }else{
                colaAux.encolar(c);
            }
        }
        
        while(colaAux.colaVacia()==false){
            listaC.encolar(colaAux.desencolar());
        }
            
        if(estado == false){
            listaC.encolar(refC);
            JOptionPane.showMessageDialog(null, "Cliente encolado con éxito.");
        }else{
            JOptionPane.showMessageDialog(null, "Ya existe un cliente con el Dni: " + refC.getDni());
        }
    }

//metodo para ver la cola de clientes
    public String verColaClientes(){
        String cad="";        
        ArrayCola<Cliente> cAux=new ArrayCola<Cliente>();
        int i=1;
        
        while(listaC.colaVacia()==false){
            Cliente refC=listaC.desencolar();
            cad=cad+""+
                "\n  Cliente "+(i++)+": \n"+refC.toString();
            cAux.encolar(refC);
        }
        
        while(cAux.colaVacia()==false){
            listaC.encolar(cAux.desencolar());
        }       
        return cad;
    }

//metodo para calcular monto recaudado de la caja
    public void calcularRecaudacion(){
        Cliente ref;
        while(listaC.colaVacia()==false){
            ref=listaC.desencolar();            
            montoRCaja+=ref.getMontoaPagar();
        }
        
    }    
    
}
