
package misClases;
import java.util.Random;
import javax.swing.*;

public class Tienda {
    
    private int codSucursal;
    private String distritoUbi;
    private CajaDePago arCP[] = new CajaDePago[10];

    public Tienda(int codSucursal, String distritoUbi) {
        this.codSucursal = codSucursal;
        this.distritoUbi = distritoUbi;
        CajaDePago arCP[] = new CajaDePago[10];
    }

    public int getCodSucursal() {
        return codSucursal;
    }

    public String getDistritoUbi() {
        return distritoUbi;
    }

    public CajaDePago[] getArCP() {
        return arCP;
    }

    public void insertarCliente(Cliente refC){
        Random ran = new Random();
        CajaDePago cajaP = new CajaDePago();
        int dni = refC.getDni();
        
        int randito = ran.nextInt(arCP.length);
        if (arCP[randito]==null){
            arCP[randito] = cajaP;
            cajaP.agregarClienteEnCola(refC);
        }else{
            arCP[randito].agregarClienteEnCola(refC);
        }
    }
    
    public String VerInformacionCajas(){
        String cad = "";
        for(int i = 0; i < arCP.length; i++){
            if(arCP[i] != null){
                cad += "\n \n -Caja Nro "+(i+1)+": "+arCP[i].verColaClientes();
            }
        }
        return cad;
    }
    
    public float VerTotalRecaudado(){
        float TotalRecaudado = 0.0f;
        
        for(int i = 0; i < arCP.length; i++){
            if(arCP[i] != null){
                arCP[i].calcularRecaudacion();
                TotalRecaudado += arCP[i].getMontoRCaja();
            }
        }
        
        return TotalRecaudado;
    }
}
