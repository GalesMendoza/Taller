
package misClases;


public class Cliente {
//declaracion de variables
     protected int dni;
     protected float montoaPagar;
//constructor
    public Cliente(int dni, float montoaPagar) {
        this.dni = dni;
        this.montoaPagar=montoaPagar;
    }
//getters
    public int getDni() {
        return dni;
    }
    public float getMontoaPagar() {
        return montoaPagar;
    }
//setters
    public void setDni(int dni) {
        this.dni = dni;
    }
    public void setMontoaPagar(float montoaPagar) {
        this.montoaPagar = montoaPagar;
    }
    
    public String toString() {
        return "     Dni: "+dni
                +"\n     Monto a pagar: "+montoaPagar;
    }
    
}