package miClaseLista;

import javax.swing.JOptionPane;
import misClases.Tienda;

public class ListaE <E extends Tienda>{
    private NodoE<E> primero;
    private int talla;        // saber el numero de nodos

    public ListaE() {
        this.primero=null;
        this.talla=0;
    }

    public NodoE<E> getPrimero() {
        return primero;
    }
    public int getTalla() {
        return talla;
    }
     //reglas de negocio u operaciones
    public void insertarAlInicio(E refT){
        NodoE<E> nuevo=new NodoE<>(refT);
        
        nuevo.setSiguiente(primero);
        primero=nuevo;
        talla++;       
    }
    
    public void insertarAlFinal(E refT){
        NodoE<E> nuevo=new NodoE<>(refT);
        NodoE<E> aux=primero;
        
        if(primero==null){
            primero=nuevo;
        }else{
            while(aux.getSiguiente()!=null){
                aux=aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
        talla++;       
    }
    
    //método que elimina el primer nodo
    public void eliminarAlInicio(){        
        if(primero.getSiguiente()==null){
            primero=null;
        }else{
            primero=primero.getSiguiente();
        }
        talla--;
    }
    
    //método que eliminar al final de la lista
    public void eliminarAlFinal(){        
        if(primero.getSiguiente()==null){
            primero=null;
        }else{
            NodoE<E> aux=primero,ant=null;
            while(aux.getSiguiente()!=null){
                ant=aux;
                aux=aux.getSiguiente();
            }
            ant.setSiguiente(null);
        }
        talla--;
    }
    
    public void eliminarTienda(int codSucursal){
        NodoE<E> aux=primero, ant=null;
        
        while(aux!=null && aux.getDato().getCodSucursal()!=codSucursal){
            ant=aux;
            aux=aux.getSiguiente();
        }
        
        if(aux!=null){
            if(aux==primero){
                eliminarAlInicio();
                JOptionPane.showMessageDialog(null,"Tienda eliminada con exito.");
            }else if(aux.getSiguiente()==null){
                eliminarAlFinal();
                JOptionPane.showMessageDialog(null,"Tienda eliminada con exito.");
            }else{
                ant.setSiguiente(aux.getSiguiente());
                talla--;
            }
        }else{
            JOptionPane.showMessageDialog(null, "No existe Tienda de codigo: "+ codSucursal);
        }       
    }
    
    public boolean insertarOrdenado(E x){
        NodoE<E> nuevo = new NodoE<E>(x);
        NodoE<E> aux, ant=null;
        if(primero == null){
            primero = nuevo;
            talla++;
            return true;
        }else{
            aux = primero;
            while(aux != null && aux.getDato().getDistritoUbi().compareToIgnoreCase(x.getDistritoUbi()) != 0){
                aux = aux.getSiguiente();
            }
            if(aux == null){
                aux = primero;
                while(aux != null && aux.getDato().getCodSucursal() < x.getCodSucursal()){
                    ant = aux;
                    aux = aux.getSiguiente();
                }
                if(aux != null){
                    if(aux.getDato().getCodSucursal() == x.getCodSucursal()){
                        JOptionPane.showMessageDialog(null, "Ya existe una tienda con código:  "+aux.getDato().getCodSucursal());
                        return false;
                    }else{
                        if(aux == primero){
                            insertarAlInicio(x);
                        }else{
                            ant.setSiguiente(nuevo);
                            nuevo.setSiguiente(aux);
                            talla++;
                        }
                        return true;
                    }
                }else{
                    insertarAlFinal(x);
                    return true;
                }
            }else{
                JOptionPane.showMessageDialog(null, "Ya existe una tienda en el distrito de: "+aux.getDato().getDistritoUbi());
                return false;
            }
        }
    }
    
    public Tienda buscarTienda(int codSucursal){
        NodoE<E> aux = primero;
        while(aux != null && aux.getDato().getCodSucursal() != codSucursal){
            aux = aux.getSiguiente();
        }
        return aux != null ? aux.getDato() : null;
    }
    
    public String VerTiendasTotalRecaudado(){
        String cad = "";
         
        
        NodoE<E> aux = primero;
        while(aux != null){
            cad += "\n Tienda en: " + aux.getDato().getDistritoUbi() + "\n  Monto total recaudado: "+aux.getDato().VerTotalRecaudado();
            aux = aux.getSiguiente();
        }
        return cad;
    }
    
}