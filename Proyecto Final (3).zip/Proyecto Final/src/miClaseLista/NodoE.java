package miClaseLista;

public class NodoE <E>{
    private E dato;
    private NodoE<E> siguiente;

    public NodoE(E dato) {
        this.dato = dato;
        this.siguiente=null;
    }

    public E getDato() {
        return dato;
    }
    public void setDato(E dato) {
        this.dato = dato;
    }
    public NodoE<E> getSiguiente() {
        return siguiente;
    }
    public void setSiguiente(NodoE<E> siguiente) {
        this.siguiente = siguiente;
    }   
}
