package miClaseLista;

import java.util.Random;
import javax.swing.JOptionPane;
import misClases.CajaDePago;
import misClases.Tienda;


public class ListaLEG<E extends Tienda> {
    private NodoLEG<E> primero;
    private int talla; 

    public ListaLEG() {
        this.primero=null;
        this.talla=0;
    }

    public NodoLEG<E> getPrimero() {
        return primero;
    }
    public int getTalla() {
        return talla;
    }
    public void insertarAlInicio(E x){        
        NodoLEG<E> nuevo=new NodoLEG<>(x);        
        nuevo.setSiguiente(primero);        
        primero = nuevo;
        talla++;
    }
    public void insertarAlFinal(E x){        
        NodoLEG<E> nuevo=new NodoLEG<>(x);    
        NodoLEG<E> aux=primero;
        
        if(primero ==null){
            primero=nuevo;
        }else{
            while(aux.getSiguiente()!=null){
                aux=aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
        talla++;       
    }    
        
    //reglas de negocio
    public void agregarTiendaOrdenada(E x){
        NodoLEG<E> nuevo=new NodoLEG<E>(x);
        
        NodoLEG<E> aux=primero, ant=null;        
        if(primero==null){
            primero=nuevo;
            talla++;
        }else{
            while(aux!=null && aux.getDato().getNumCaja()<x.getNumCaja()){
                ant=aux;
                aux=aux.getSiguiente();
            }
            if(aux!=null){
                if(aux.getDato().getNumCaja()==x.getNumCaja()){
                    JOptionPane.showMessageDialog(null, "La tienda ya existe");
                }else if(aux==primero){
                    insertarAlInicio(x);
                }else{
                    ant.setSiguiente(nuevo);
                    nuevo.setSiguiente(aux);
                    talla++;
                }
            }else{
                insertarAlFinal(x);
            }           
        }       
    }
    
    public void agregarClienteEnCajaAleatoria(Cliente refc){
        Random randito=new Random();
        
        int valor=randito.nextInt(talla)+1;
        NodoLEG<E> aux=primero;
        
        for (int i = 1; i < valor; i++) {
            aux=aux.getSiguiente();
        }
        aux.getDato().agregarClienteEnCola(refc);       
    }
    
    
    
    
    
    
    
    
    
    
    
}
