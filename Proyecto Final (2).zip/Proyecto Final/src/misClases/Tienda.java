
package misClases;
import java.util.ArrayList;
import javax.swing.*;
import miClaseLista.ListaLEG;


public class Tienda {
    
    private String codSucursal;
    private String distritoUbi;
    CajaDePago[]   ArrayTienda = new  CajaDePago[10];

    public Tienda(String codSucursal, String distritoUbi) {
        this.codSucursal = codSucursal;
        this.distritoUbi = distritoUbi;
        
    }
    
    
    
    
}
