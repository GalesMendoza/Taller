
package misClases;

import archivo.cola.ArrayCola;

public class CajaDePago {
//declaracion de variables
    private ArrayCola<Cliente> listaC;
    private float montoRCaja;
//contructor
    public CajaDePago() {
        listaC=new ArrayCola<Cliente>();
        montoRCaja=0.0f;
    }
//getters
    public ArrayCola<Cliente> getListaC() {
        return listaC;
    }
    public float getMontoRCaja() {
        return montoRCaja;
    }

//metodo asignar clientes a la cola
    public void agregarClienteEnCola(Cliente refC){
        listaC.encolar(refC);
    }

//metodo para ver la cola de clientes
    public String verColaClientes(){
        String cad="";        
        ArrayCola<Cliente> cAux=new ArrayCola<Cliente>();
        
        while(listaC.colaVacia()==false){
            Cliente refc=listaC.desencolar();
            cad+=refc.toString()+"\n";
            cAux.encolar(refc);
        }
        
        while(cAux.colaVacia()==false){
            listaC.encolar(cAux.desencolar());
        }       
        return cad;
    }

//metodo para calcular monto recaudado de la caja
    public void calcularRecaudacion(){
        Cliente ref;
        while(listaC.colaVacia()==false){
            ref=listaC.desencolar();            
            montoRCaja+=ref.getMontoaPagar();
        }
        
    }    
    
    
    
}
