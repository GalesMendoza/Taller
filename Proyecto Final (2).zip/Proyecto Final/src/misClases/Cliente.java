
package misClases;


public class Cliente {
//declaracion de variables
     protected String dni;
     protected float montoaPagar;
//constructor
    public Cliente(String dni, float montoaPagar) {
        this.dni = dni;
        this.montoaPagar=montoaPagar;
    }
//getters
    public String getDni() {
        return dni;
    }
    public float getMontoaPagar() {
        return montoaPagar;
    }
//setters
    public void setDni(String dni) {
        this.dni = dni;
    }
    public void setMontoaPagar(float montoaPagar) {
        this.montoaPagar = montoaPagar;
    }
    
    
}